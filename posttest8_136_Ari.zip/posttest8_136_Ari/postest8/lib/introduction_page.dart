import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:postest7/kacamata_page.dart';

class Introduction_page extends StatelessWidget {
  const Introduction_page({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: IntroductionScreen(
        next: Text("Selanjutnya"),
        done: Text("Selesai"),
        onDone: () {
          Navigator.of(context).pop();
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) {
                return KacamataPage();
              },
            ),
          );
        },
        pages: [
          PageViewModel(
            title: "Selamat Datang Di Kacamata store",
            body:
                "Pilihlah dari berbagai merek terkenal dan berbagai jenis kacamata. Kami hadirkan beragam pilihan untuk gaya Anda",
            image: Image.asset("assets/awal.jpg"),
          ),
          PageViewModel(
            title: "LOGO",
            body: "Tampilan logo 1",
            image: Image.asset("assets/logo1.jpg"),
          ),
          PageViewModel(
            title: "LOGO",
            body: "Tampilan logo 2",
            image: Image.asset("assets/logo2.jpg"),
          ),
        ],
      ),
    );
  }
}
