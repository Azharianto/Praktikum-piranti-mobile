import 'package:flutter/material.dart';
import 'produk_page.dart';
import 'about_page.dart';

class KacamataPage extends StatelessWidget {
  void _navigateToProdukPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProdukPage()),
    );
  }

  void _navigateToAboutPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AboutPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // header dari sidbar
            const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.green,
                ),
                child: Align(
                  alignment: Alignment.center,
                  child: Text(
                    'Kacamata Store',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                )),
            //list page di sidebar
            ListTile(
                title: const Text(
                  "Home",
                  style: TextStyle(fontSize: 20),
                ),
                onTap: () {
                  Navigator.of(context).pushNamed('/kacamata');
                }),
            ListTile(
              title: const Text(
                "aboutme",
                style: TextStyle(fontSize: 20),
              ),
              onTap: () {
                Navigator.of(context).pushNamed('/about');
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: Text('Kacamata Store'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 300,
              height: 200,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/awal.jpg'),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                _navigateToProdukPage(context);
              },
              child: Text('Lihat Produk'),
            ),
          ],
        ),
      ),
    );
  }
}
