package com.example.postest7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
