import 'package:flutter/material.dart';
import 'kacamata_page.dart';
import 'about_page.dart';
import 'introduction_page.dart';

void main() {
  runApp(KacamataStoreApp());
}

class KacamataStoreApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kacamata Store',
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.blue,
        appBarTheme: AppBarTheme(backgroundColor: Colors.green),
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: Colors.black),
          bodyMedium: TextStyle(color: Colors.black),
        ),
      ),
      darkTheme: ThemeData.dark().copyWith(
        primaryColor: Colors.blue,
        appBarTheme: AppBarTheme(backgroundColor: Colors.green),
        textTheme: TextTheme(
          bodyLarge: TextStyle(fontSize: 18, color: Colors.white),
          bodyMedium: TextStyle(fontSize: 10, color: Colors.white),
        ),
      ),
      home: Introduction_page(),
      routes: {
        '/kacamata': (context) => KacamataPage(),
        '/about': (context) => AboutPage(),
      },
    );
  }
}
