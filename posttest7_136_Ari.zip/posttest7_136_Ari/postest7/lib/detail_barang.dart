import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class DetailBarangPage extends StatelessWidget {
  final String productName;

  DetailBarangPage(this.productName);

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: Text('Detail Barang'),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 68, 70, 68),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Center(
                child: Image.asset(
                  _getImageForProduct(productName),
                  width: 100,
                  height: 100,
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Nama Barang: $productName',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            SizedBox(height: 10),
            Text(
              'Harga: Rp 10.000',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            SizedBox(height: 20),
            CupertinoButton(
                child: Text('Beli Barang'),
                onPressed: () {
                  _showPurchaseDialog(context);
                },
                color: Colors.green),
          ],
        ),
      ),
    );
  }

  void _showPurchaseDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Isi Informasi Pembelian'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                decoration: InputDecoration(labelText: 'Nama'),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Nomor HP'),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Alamat'),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Email'),
              ),
            ],
          ),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Beli'),
            ),
          ],
        );
      },
    );
  }

  String _getImageForProduct(String productName) {
    if (productName == 'Kacamata Bulat 1') {
      return './assets/kacamata1.jpg';
    } else if (productName == 'Kacamata Bulat 2') {
      return './assets/kacamata2.jpg';
    } else if (productName == 'Kacamata Bulat 3') {
      return './assets/kacamata3.jpg';
    } else if (productName == 'Kacamata Bulat 4') {
      return './assets/kacamata4.jpg';
    } else if (productName == 'Kacamata Bulat 5') {
      return './assets/kacamata5.jpg';
    } else if (productName == 'Kacamata Bulat 6') {
      return './assets/kacamata6.jpg';
    }
    return '';
  }
}
