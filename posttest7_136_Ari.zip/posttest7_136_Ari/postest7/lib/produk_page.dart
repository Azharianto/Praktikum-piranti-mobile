import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'detail_barang.dart';

class ProdukPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Produk Kacamata'),
      ),
      body: ListView(
        children: <Widget>[
          _buildProductItem(
            './assets/kacamata1.jpg',
            'Kacamata Bulat 1',
            'Harga: Rp 10.000',
            context,
          ),
          _buildProductItem(
            './assets/kacamata2.jpg',
            'Kacamata Bulat 2',
            'Harga: Rp 20.000',
            context,
          ),
          _buildProductItem(
            './assets/kacamata3.jpg',
            'Kacamata Bulat 3',
            'Harga: Rp 30.000',
            context,
          ),
          _buildProductItem(
            './assets/kacamata4.jpg',
            'Kacamata Bulat 4',
            'Harga: Rp 40.000',
            context,
          ),
          _buildProductItem(
            './assets/kacamata5.jpg',
            'Kacamata Bulat 5',
            'Harga: Rp 50.000',
            context,
          ),
          _buildProductItem(
            './assets/kacamata6.jpg',
            'Kacamata Bulat 6',
            'Harga: Rp 60.000',
            context,
          ),
          
          SizedBox(height: 100), 
        ],
      ),
    );
  }

  ListTile _buildProductItem(
    String imageAsset,
    String productName,
    String price,
    BuildContext context,
  ) {
    return ListTile(
      leading: Image.asset(
        imageAsset,
        width: 100,
        height: 100,
      ),
      title: Text(
        productName,
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
        price,
        style: TextStyle(fontSize: 15, color: Colors.black),
      ),
      trailing: ElevatedButton(
        onPressed: () {
          _navigateToDetailPage(context, productName); 
        },
        child: Text('Lihat Detail'),
      ),
    );
  }

  void _navigateToDetailPage(BuildContext context, String productName) {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) => DetailBarangPage(productName),
      ),
    );
  }
}

